﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProiectDAW.Models
{
    public class ToDo
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Numele task-ului este obligatoriu")]
        [StringLength(50, ErrorMessage = "Dimeniunea maxima este de 50 de caractere")]
        [MinLength(3, ErrorMessage = "Dimensiunea minimă este de 3 caractere")]
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }

        //un todo list are asociat un singur planner
        public int PlannerId { get; set; }
        public virtual Planner? Planner { get; set; }
    }
}
