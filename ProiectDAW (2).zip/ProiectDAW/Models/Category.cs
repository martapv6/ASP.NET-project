﻿using System.ComponentModel.DataAnnotations;
using System.Threading.Channels;

namespace ProiectDAW.Models
{
    public class Category
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Numele categoriei este obligatoriu")]
        [StringLength(50, ErrorMessage = "Dimeniunea maxima este de 50 de caractere")]
        [MinLength(3, ErrorMessage = "Dimensiunea minimă este de 3 caractere")]
        public string Name { get; set; }
        public virtual ICollection<Channel>? Channels { get; set; }
    }
}
