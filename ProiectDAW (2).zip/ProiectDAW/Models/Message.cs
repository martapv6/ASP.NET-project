﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace ProiectDAW.Models
{
    public class Message
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Mesajul trebuie sa aiba un continut")]
        public string Content { get; set; }
        public DateTime SentTime { get; set; }


        //un mesaj apartine unui singur canal
        public int ChannelId { get; set; }
        public virtual Channel? Channel { get; set; }


        //un mesaj e postat de un singur user
        public string? UserId { get; set; }
        public virtual ApplicationUser? User { get; set; }

        //public int Test { get; set; }
    }

}
