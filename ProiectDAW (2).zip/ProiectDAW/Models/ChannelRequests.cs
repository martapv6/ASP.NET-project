﻿using System.ComponentModel.DataAnnotations;

namespace ProiectDAW.Models
{
    public class ChannelRequests
    {
        [Key]
        public int Id { get; set; }
        public string? UserId { get; set; }
        public virtual ApplicationUser? User { get; set; }
        public int? ChannelId { get; set; }
        public virtual Channel? Channel { get; set; }

    }
}
