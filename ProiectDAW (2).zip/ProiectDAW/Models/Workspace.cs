﻿using System.ComponentModel.DataAnnotations;

namespace ProiectDAW.Models
{
    public class Workspace
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Numele spatiului de lucru este obligatriu")]
        [StringLength(50, ErrorMessage = "Dimeniunea maxima este de 50 de caractere")]
        [MinLength(3, ErrorMessage = "Dimensiunea minimă este de 3 caractere")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Descrierea spatiului de lucru este obligatorie")]
        [StringLength(200, ErrorMessage = "Dimeniunea maxima este de 200 de caractere")]
        [MinLength(3, ErrorMessage = "Dimensiunea minimă este de 3 caractere")]
        public string Description { get; set; }
        public virtual ICollection<Channel>? Channels { get; set; }

    }
}
