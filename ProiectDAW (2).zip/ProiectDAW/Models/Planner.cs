﻿using System.ComponentModel.DataAnnotations;

namespace ProiectDAW.Models
{
    public class Planner
    {
        [Key]
        public int Id { get; set; }

        //un user are un singur planner
        public string UserId { get; set; }
        public virtual ApplicationUser User { get; set; }
        public virtual ICollection<ToDo>? ToDos { get; set; } = new List<ToDo>();

        public int Test { get; set; }
    }
}
