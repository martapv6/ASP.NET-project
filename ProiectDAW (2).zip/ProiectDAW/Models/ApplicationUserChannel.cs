﻿using System.Threading.Channels;

namespace ProiectDAW.Models
{
    public class ApplicationUserChannel
    {
        //tabel asociativ
        //un user poate fi in mai multe canale
        //un canal poate avea mai multi useri
        public string? UserId { get; set; }
        public int? ChannelId { get; set; }
        public bool? IsModerator { get; set; }

        public virtual ApplicationUser? User { get; set; }
        public virtual Channel? Channel { get; set; }
    }
}
