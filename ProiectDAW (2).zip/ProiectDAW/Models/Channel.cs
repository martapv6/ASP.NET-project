﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProiectDAW.Models
{
    public class Channel
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Numele canalului este obligatoriu")]
        [StringLength(50, ErrorMessage = "Dimeniunea maxima este de 50 de caractere")]
        [MinLength(3, ErrorMessage = "Dimensiunea minimă este de 3 caractere")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Descrierea canalului este obligatorie")]
        [StringLength(200, ErrorMessage = "Dimeniunea maxima este de 200 de caractere")]
        public string Description { get; set; }



        //un canal are o singura categorie
        [Required(ErrorMessage = "Categoria este obligatorie")]
        public int? CategoryId { get; set; }
        public virtual Category? Category { get; set; }
        [NotMapped]
        public IEnumerable<SelectListItem> CategoriesList { get; set; }



        //un canal e intr-un singur workspace
        public int? WorkspaceId { get; set; }
        public virtual Workspace? Workspace { get; set; }



        //un canal are mai multe mesaje
        public virtual ICollection<Message>? Messages { get; set; }



        //un canal are mai multi useri
        //public string? UserId { get; set; }
        //public virtual ApplicationUser? User { get; set; }
        public virtual ICollection<ApplicationUserChannel>? ApplicationUserChannels { get; set; }

        //teoretic un canal are mai multi moderatori
        public string? ModeratorId { get; set; }
        public virtual ApplicationUser? Moderator { get; set; }
        public virtual ICollection<ChannelRequests>? ChannelRequests { get; set; }

    }
}
