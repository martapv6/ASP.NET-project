﻿using Microsoft.AspNetCore.Identity;

namespace ProiectDAW.Models
{
    public class ApplicationUser : IdentityUser
    {
        //nu stiu unde mi le pune ca,campuri si am eroare ca imi zice ca sunt not null si trebuie sa pun ceva neaprat
     //  public   string FirstName { get; set; }  
      //  public  string LastName { get; set; }   
     // public  string? Address { get; set; }   
      // public string? PhoneNumber { get; set; } 
        //un user se afla in ami multe canale - many-yo-many cu Channel
        public virtual ICollection<ApplicationUserChannel>? ApplicationUserChannels { get; set; }
        public virtual ICollection<Message>? Messages { get; set; }
        public virtual ICollection<Notification>? Notifications { get; set; }
        public virtual Planner? Planner { get; set; }
    }
}
