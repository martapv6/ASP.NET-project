﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using ProiectDAW.Data;
using ProiectDAW.Models;

namespace ProiectDAW.Controllers
{
    public class CategoriesController : Controller
    {
        private readonly ApplicationDbContext db;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public CategoriesController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            RoleManager<IdentityRole> roleManager)
        {
            db = context;
            _userManager = userManager;
            _roleManager = roleManager;
        }

        public IActionResult Index()
        {
            var categories = from category in db.Categories
                             orderby category.Name
                             select category;

            ViewBag.Categories = categories.ToList();


            return View();
        }

        // Restul metodelor pentru CRUD rămân la fel

        // Permite doar admin-ului să adauge o categorie
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult New(Category c)
        {
            if (ModelState.IsValid)
            {
                db.Categories.Add(c);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }

        // Permite doar admin-ului să editeze o categorie
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult Edit(int id, Category requestCategory)
        {
            if (id != requestCategory.Id)
            {
                return BadRequest();
            }

            var category = db.Categories.Find(id);
            if (category == null)
            {
                return NotFound();
            }

            category.Name = requestCategory.Name;
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        // Permite doar admin-ului să șteargă o categorie
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult Delete(int id)
        {
            var category = db.Categories.Find(id);
            if (category == null)
            {
                return NotFound();
            }

            db.Categories.Remove(category);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
