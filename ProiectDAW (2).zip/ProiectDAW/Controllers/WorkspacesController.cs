﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProiectDAW.Data;
using ProiectDAW.Models;

namespace ProiectDAW.Controllers
{
    public class WorkspacesController : Controller
    {

        private readonly ApplicationDbContext db;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        public WorkspacesController(
        ApplicationDbContext context,
        UserManager<ApplicationUser> userManager,
        RoleManager<IdentityRole> roleManager)
        {
            db = context;
            _userManager = userManager;
            _roleManager = roleManager;
        }


        [Authorize(Roles = "User,Moderator,Admin")]
        public ActionResult Index()
        {
            if (TempData.ContainsKey("message"))
            {
                ViewBag.message = TempData["message"].ToString();
            }

            var workspaces = from workspace in db.Workspaces
                             orderby workspace.Name
                             select workspace;

            if (workspaces == null)
                NotFound();

            ViewBag.Workspaces = workspaces;
            return View();
        }

        [Authorize(Roles = "User,Moderator,Admin")]
        public ActionResult Show(int id)
        {
            Workspace workspace = db.Workspaces.Include("Channels")
                                 .Where(w => w.Id == id)
                                 .First();
            if (workspace == null)
                NotFound();

            return View(workspace);
        }

        [Authorize(Roles = "User,Moderator,Admin")]
        public ActionResult ShowChannels(int? worskapceId)
        {
            var userId = _userManager.GetUserId(User);
            if (userId == null)
                return NotFound();

            var userChannels = db.Channels
                .Include(c => c.Workspace!)
                .Include(c => c.ApplicationUserChannels!)
                .ThenInclude(uc => uc.User)
                .Where(c => c.ApplicationUserChannels!.Any(uc => uc.UserId == userId))
                .ToList();

            if (userChannels == null)
                return NotFound();
            return View(userChannels);

        }

        [Authorize(Roles = "User,Moderator,Admin")]
        public ActionResult New()
        {
            Workspace workspace = new Workspace();
            return View();
        }

        [Authorize(Roles = "User,Moderator,Admin")]
        [HttpPost]
        public ActionResult New(Workspace worksapce)
        {
            if (ModelState.IsValid)
            {
                db.Workspaces.Add(worksapce);
                db.SaveChanges();
                TempData["message"] = "Workspace-ul a fost adaugat";
                return RedirectToAction("Index");
            }
            else
            {
                return View(worksapce);
            }
        }
    }
}
