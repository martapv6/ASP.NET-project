﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using ProiectDAW.Data;
using ProiectDAW.Models;

namespace ProiectDAW.Controllers
{
    public class MessagesController : Controller
    {
        private readonly ApplicationDbContext db;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        public MessagesController(
        ApplicationDbContext context,
        UserManager<ApplicationUser> userManager,
        RoleManager<IdentityRole> roleManager)
        {
            db = context;
            _userManager = userManager;
            _roleManager = roleManager;
        }

        public IActionResult Index()
        {
            {
                var messages = from message in db.Messages
                               select message;

                ViewBag.Messages = messages.ToList();
                return View();
            }
        }

        [HttpPost]
        public IActionResult New(Message c)
        {
            if (ModelState.IsValid)
            {
                db.Messages.Add(c);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpPost]
            public ActionResult DeleteMessage(int messageId)
            {
                var message = db.Messages.Find(messageId);
                if (message == null)
                    NotFound();

                var userId = _userManager.GetUserId(User);
                if (userId == null)
                    NotFound();

                var isModerator = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == message.ChannelId && cu.IsModerator == true);

                if (userId == message.UserId || isModerator == true)
                {
                    db.Messages.Remove(message);
                    db.SaveChanges();
                }
                return Redirect("/Channels/Show/" + message.ChannelId);
            }


            [Authorize(Roles = "User,Moderator,Admin")]
            ActionResult EditMessage(int messageId)
            {
                Message message = db.Messages.Find(messageId);
                if (message == null)
                    NotFound();

                var userId = _userManager.GetUserId(User);
                if (userId == null)
                    NotFound();

                var isModerator = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == message.ChannelId && cu.IsModerator == true);
                if (message.UserId == userId || isModerator == true)
                {
                    return View(message);
                }
                else
                {
                    TempData["messages"] = "Nu aveti dreptul";
                    TempData["messsageType"] = "alert-danger";
                    return Redirect("/Channels/Show/" + message.ChannelId);
                }

            }

            [HttpPost]
            [Authorize(Roles = "User,Moderator,Admin")]
             ActionResult EditMessage(int messageId,Message newMessage)
            {
                Message message = db.Messages.Find(messageId);
                if (message == null)
                    NotFound();

                var userId = _userManager.GetUserId(User);
                if (userId == null)
                    NotFound();

                if (message.UserId == userId)
                {
                    //ModelstateIsValide
                    message.Content = newMessage.Content;
                    db.SaveChanges();
                }
                return Redirect("/Channels/Show/" + message.ChannelId);

            }
        }
    }

