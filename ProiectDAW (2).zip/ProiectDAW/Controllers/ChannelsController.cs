﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.VisualStudio.Web.CodeGeneration.Utils;
using ProiectDAW.Data;
using ProiectDAW.Models;
using System.Data;

namespace ProiectDAW.Controllers
{
    public class ChannelsController : Controller
    {

        private readonly ApplicationDbContext db;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        public ChannelsController(
        ApplicationDbContext context,
        UserManager<ApplicationUser> userManager,
        RoleManager<IdentityRole> roleManager)
        {
            db = context;
            _userManager = userManager;
            _roleManager = roleManager;
        }

        public IActionResult Index()
        {
            var channels = from channel in db.Channels
                             orderby channel.Name
                             select channel;

            ViewBag.Categories = channels.ToList(); // Set the categories to ViewBag

            return View(); // View is automatically using ViewBag.Categories
        }
        [HttpPost]
        [Authorize(Roles = "User,Moderator,Admin")]
        public ActionResult JoinRequests(int channelId)
        {
            var userId = _userManager.GetUserId(User);
            var existingRequest = db.ChannelRequests.Any(r => r.UserId == userId && r.ChannelId == channelId);
            var isMember = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == channelId);

            if (userId == null)
                return NotFound();

            if (existingRequest || isMember)
                return BadRequest();

            var newRequest = new ChannelRequests
            {
                UserId = userId,
                ChannelId = channelId
            };

            if (ModelState.IsValid)
            {
                db.ChannelRequests.Add(newRequest);
                db.SaveChanges();
            }

            return RedirectToAction("Show", new { id = channelId });
        }







        [Authorize(Roles = "User,Moderator,Admin")]
        public ActionResult Requests(int? channelId)
        {
            var userId = _userManager.GetUserId(User);

            if (userId == null)
                return NotFound();

            var isModerator = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == channelId && cu.IsModerator == true);

            if (!isModerator)
                return Unauthorized();

            var request = db.ChannelRequests
                         .Include(r => r.User)
                         .Where(r => r.ChannelId == channelId);

            ViewBag.Requests = request;
            ViewBag.ChannelId = channelId;
            return View();
        }








        [Authorize(Roles = "User,Moderator,Admin")]
        [HttpPost]
        public ActionResult ApproveRequest(int requestId)
        {
            var userId = _userManager.GetUserId(User);
            if (userId == null)
                return NotFound();

            var request = db.ChannelRequests.Include(r => r.Channel).FirstOrDefault(r => r.Id == requestId);
            if (request == null)
                return NotFound();

            var isModerator = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == request.ChannelId && cu.IsModerator == true);
            if (!isModerator)
                return Unauthorized();

            var newMember = new ApplicationUserChannel
            {
                UserId = request.UserId,
                ChannelId = request.ChannelId,
                IsModerator = false
            };


            db.ApplicationUserChannels.Add(newMember);
            db.ChannelRequests.Remove(request);
            db.SaveChanges();

            return RedirectToAction("Requests", new { channelId = request.ChannelId });
        }





        [Authorize(Roles = "User,Moderator,Admin")]
        [HttpPost]
        public ActionResult RejectRequest(int requestId)
        {
            var userId = _userManager.GetUserId(User);

            if (userId == null)
                return NotFound();

            var request = db.ChannelRequests.FirstOrDefault(r => r.Id == requestId);

            if (request == null)
                return NotFound();

            var isModerator = db.ApplicationUserChannels.Any(cu => cu.ChannelId == request.ChannelId && cu.IsModerator == true);

            if (!isModerator)
                return Unauthorized();

            db.ChannelRequests.Remove(request);
            db.SaveChanges();
            return RedirectToAction("Requests", new { channelId = request.ChannelId });
        }






        [Authorize(Roles = "User,Moderator,Admin")]
        public ActionResult Show(int id)
        {
            var userId = _userManager.GetUserId(User);
            if (userId == null)
                return NotFound();

            var isMember = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == id);
            var hasPendingRequest = db.ChannelRequests.Any(cr => cr.UserId == userId && cr.ChannelId == id);
            var isModerator = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == id && cu.IsModerator == true);

#nullable disable
            var channel = db.Channels
                    .Include(c => c.Messages)
                    .ThenInclude(m => m.User)
                    .Include(c => c.ChannelRequests)
                    .ThenInclude(cr => cr.User)
                    .FirstOrDefault(c => c.Id == id);
#nullable restore

            ViewBag.IsMember = isMember;
            ViewBag.UserCurent = userId;
            ViewBag.HasPendingRequest = hasPendingRequest;
            ViewBag.IsModerator = isModerator;
            return View(channel);
        }







        [Authorize(Roles = "User,Moderator,Admin")]
        public ActionResult ShowUsers(int id)
        {
            var userId = _userManager.GetUserId(User);
            if (userId == null)
                return NotFound();

            var isModerator = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == id && cu.IsModerator == true);
            var channel = db.Channels
                .Include(c => c.ApplicationUserChannels!)
                .ThenInclude(uc => uc.User)
                .FirstOrDefault(c => c.Id == id);

            if (channel == null)
                NotFound();

            var usersInChannel = channel.ApplicationUserChannels.ToList();

            ViewBag.IsModerator = isModerator;
            ViewBag.ChannelId = channel.Id;
            return View(usersInChannel);
        }







        [Authorize(Roles = "User,Moderator,Admin")]
        [HttpPost]
        public ActionResult Show([FromForm] Message message)
        {
            message.SentTime = DateTime.Now;

            var user = _userManager.GetUserId(User);
            if (user == null)
                return NotFound();
            message.UserId = user;

            //if(ModelState.IsValid)
            {
                db.Messages.Add(message);
                db.SaveChanges();
                return Redirect("/Channels/Show/" + message.ChannelId);
            }
            /*
            else
            {
                #nullable disable
                var channel = db.Channels
                        .Include(c => c.Messages)
                        .ThenInclude(m => m.User)
                        .Include(c => c.ChannelRequests)
                        .ThenInclude(cr => cr.User)
                        .FirstOrDefault(c => c.Id == message.ChannelId);
                #nullable restore
                return View(channel);
            }
            */
        }







        [Authorize(Roles = "User,Moderator,Admin")]
        public ActionResult New(int? workspaceId)
        {
            var creatorId = _userManager.GetUserId(User);
            if (creatorId == null)
                NotFound();

            Channel channel = new Channel
            {
                WorkspaceId = workspaceId,
                CategoriesList = GetAllCategories()
            };

            return View(channel);
        }







        [Authorize(Roles = "User,Moderator,Admin")]
        [HttpPost]
        public ActionResult New(Channel channel)
        {
            var creatorId = _userManager.GetUserId(User);
            if (creatorId == null)
                NotFound();

            channel.ModeratorId = creatorId;

            //if (ModelState.IsValid)
            {
                db.Channels.Add(channel);
                db.SaveChanges();
                var channelsUser = new ApplicationUserChannel
                {
                    IsModerator = true,
                    UserId = creatorId,
                    ChannelId = channel.Id
                };

                db.ApplicationUserChannels.Add(channelsUser);
                db.SaveChanges();
                return RedirectToAction("Show", "Workspaces", new { id = channel.WorkspaceId });
            }
            /*
            else
            {
                return View(channel);
            } 
            */

        }







        [Authorize(Roles = "User,Moderator,Admin")]
        [HttpPost]
        public ActionResult DeleteChannel(int? channelId)
        {
            var userId = _userManager.GetUserId(User);
            if (userId == null)
                NotFound();

            var isModerator = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == channelId && cu.IsModerator == true);
            if (!isModerator)
                Unauthorized();

            var channel = db.Channels
                .Include(c => c.ApplicationUserChannels!)
                .ThenInclude(uc => uc.User)
                .FirstOrDefault(c => c.Id == channelId);

            if (channel == null)
                NotFound();

            var usersInChannel = db.ApplicationUserChannels.Where(uc => uc.ChannelId == channelId).ToList();
            if (usersInChannel == null)
                NotFound();

            db.ApplicationUserChannels.RemoveRange(usersInChannel);
            db.Channels.Remove(channel);
            db.SaveChanges();
            return RedirectToAction("Show", "Workspaces", new { id = channel.WorkspaceId });
        }







        [Authorize(Roles = "User,Moderator,Admin")]
        [HttpPost]
        public ActionResult DeleteUser(int? channelId, string userIdDel)
        {
            var userId = _userManager.GetUserId(User);
            if (userId == null)
                NotFound();

            var isModerator = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == channelId && cu.IsModerator == true);
            if (!isModerator)
                return Unauthorized();

            var userChannel = db.ApplicationUserChannels.FirstOrDefault(cu => cu.UserId == userIdDel && cu.ChannelId == channelId);
            if (userChannel == null)
                NotFound();

            db.ApplicationUserChannels.Remove(userChannel);
            db.SaveChanges();

            return RedirectToAction("ShowUsers", "Channels", new { id = channelId });
        }







        [Authorize(Roles = "User,Moderator,Admin")]
        [HttpPost]
        public ActionResult ModerationRights(int? channelId, string userIdMod)
        {
            var userId = _userManager.GetUserId(User);
            if (userId == null)
                NotFound();

            var isModerator = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == channelId && cu.IsModerator == true);
            if (!isModerator)
                return Unauthorized();

            var userChannel = db.ApplicationUserChannels.FirstOrDefault(cu => cu.UserId == userIdMod && cu.ChannelId == channelId);
            if (userChannel == null)
                return NotFound();

            userChannel.IsModerator = true;
            db.SaveChanges();
            return RedirectToAction("ShowUsers", "Channels", new { id = channelId });
        }







        [Authorize(Roles = "User,Moderator,Admin")]
        [HttpPost]
        public ActionResult RevokeModerationRights(int? channelId, string userIdMod)
        {
            var userId = _userManager.GetUserId(User);
            if (userId == null)
                NotFound();

            var isModerator = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == channelId && cu.IsModerator == true);
            if (!isModerator)
                return Unauthorized();

            var userChannel = db.ApplicationUserChannels.FirstOrDefault(cu => cu.UserId == userIdMod && cu.ChannelId == channelId);
            if (userChannel == null)
                return NotFound();

            userChannel.IsModerator = false;
            db.SaveChanges();
            return RedirectToAction("ShowUsers", "Channels", new { id = channelId });
        }







        [Authorize(Roles = "User,Moderator,Admin")]
        public ActionResult Edit(int? channelId)
        {
            var userId = _userManager.GetUserId(User);
            if (userId == null)
                NotFound();

            var isModerator = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == channelId && cu.IsModerator == true);
            if (!isModerator)
                return Unauthorized();

            Channel channel = db.Channels.Find(channelId);
            if (channel == null)
                return NotFound();

            return View(channel);
        }







        [Authorize(Roles = "User,Moderator,Admin")]
        [HttpPost]
        public ActionResult Edit(int channelId, Channel newChannel)
        {
            var userId = _userManager.GetUserId(User);
            if (userId == null)
                NotFound();

            var isModerator = db.ApplicationUserChannels.Any(cu => cu.UserId == userId && cu.ChannelId == channelId && cu.IsModerator == true);
            if (!isModerator)
                return Unauthorized();

            Channel channel = db.Channels.Find(channelId);
            if (channel == null)
                return NotFound();

            //ModelState.IsValid
            channel.Description = newChannel.Description;
            channel.Name = newChannel.Name;
            TempData["message"] = "Canalul a fost modificat";
            db.SaveChanges();
            return RedirectToAction("Show", new { id = channelId });

        }







        [NonAction]
        public IEnumerable<SelectListItem> GetAllCategories()
        {
            var selectList = new List<SelectListItem>();
            var categories = from cat in db.Categories
                             select cat;
            foreach (var category in categories)
            {
                selectList.Add(new SelectListItem
                {
                    Value = category.Id.ToString(),
                    Text = category.Name
                });
            }
            return selectList;
        }

    }
}
