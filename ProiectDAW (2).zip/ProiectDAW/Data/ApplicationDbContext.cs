﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ProiectDAW.Models;

//asta de pune in folderul Data (nu stiu daca l-am mai modificat de ier, dar parca nu)


namespace ProiectDAW.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Channel> Channels { get; set; }
        public DbSet<Message> Messages { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<Planner> Planners { get; set; }
        public DbSet<ToDo> ToDos { get; set; }
        public DbSet<Workspace> Workspaces { get; set; }
        public DbSet<ApplicationUserChannel> ApplicationUserChannels { get; set; }
        public DbSet<ChannelRequests> ChannelRequests { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ApplicationUserChannel>()
            .HasKey(ac => new { ac.UserId, ac.ChannelId });

            modelBuilder.Entity<ApplicationUserChannel>()
            .HasOne(ac => ac.User)
            .WithMany(ac => ac.ApplicationUserChannels)
            .HasForeignKey(ac => ac.UserId);
            modelBuilder.Entity<ApplicationUserChannel>()
            .HasOne(ac => ac.Channel)
            .WithMany(ac => ac.ApplicationUserChannels)
            .HasForeignKey(ac => ac.ChannelId);

        }

    }

}