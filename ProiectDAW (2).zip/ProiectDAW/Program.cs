﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ProiectDAW.Data;
using ProiectDAW.Models;

var builder = WebApplication.CreateBuilder(args);

// Obține string-ul de conexiune
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

// Adăugăm contextul bazei de date
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));

// Configurăm Identity pentru ApplicationUser și roluri
builder.Services.AddDefaultIdentity<ApplicationUser>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddRoles<IdentityRole>() // Adăugăm suport pentru roluri
    .AddEntityFrameworkStores<ApplicationDbContext>();

builder.Services.AddControllersWithViews();

var app = builder.Build();


// Seed data initialization
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    SeedData.Initialize(services); // Populate roles and users in the database
}

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Categories}/{action=Index}/{id?}");
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Categories}/{action=Edit}/{id?}");
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Categories}/{action=New}/{id?}");
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Categories}/{action=Show}/{id?}");


app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Workspaces}/{action=Index}/{id?}");
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Channels}/{action=Index}/{id?}");
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Channels}/{action=Edit}/{id?}");
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Channels}/{action=New}/{id?}");
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Channels}/{action=Requests}/{id?}");
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Channels}/{action=Show}/{id?}");
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Channels}/{action=Edit}/{id?}");





app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Messages}/{action=Index}/{id?}");


app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Messages}/{action=New}/{id?}");
app.MapControllerRoute(
    name: "categoriesEdit",
    pattern: "categories/edit/{id?}",
    defaults: new { controller = "Messages", action = "Edit" });

app.MapControllerRoute(
    name: "categoriesNew",
    pattern: "categories/new",
    defaults: new { controller = "Messages", action = "New" });

app.MapControllerRoute(
    name: "categoriesShow",
    pattern: "categories/show/{id?}",
    defaults: new { controller = "Messages", action = "Show" });


app.UseAuthorization();


app.MapRazorPages();

app.Run();
